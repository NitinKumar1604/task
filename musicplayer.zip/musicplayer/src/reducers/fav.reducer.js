import { ADD__FAV } from "../actions/types";


const INITIAL_STATE = {
    favourite: []
};


const favReducer = (state=INITIAL_STATE, action) => {
    // console.log(action.type);
    switch (action.type) {
      case ADD__FAV:
          // logic to add user 
        return [...state, {
          favourite: action.payload
        }]
         
      default:
        return state;
    }
  };
  export default favReducer;