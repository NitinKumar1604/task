import { ADD__RELEASE } from "../actions/types";


const INITIAL_STATE = {
    release: ''
};


const releaseReducer = (state=INITIAL_STATE, action) => {
  console.log(action.type)  
  switch (action.type) {
      case ADD__RELEASE:
          // logic to add user 
        return {
          ...state,
          release: action.payload,
        }  
      default:
        return state;
    }
  };

  export default releaseReducer;