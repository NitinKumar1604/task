import { combineReducers } from "redux";
import barinzReducer from "./brainz.reducer";
import favReducer from "./fav.reducer";
import FmReducer from "./fm.reducer";
import releaseReducer from "./release";

const allReducer = combineReducers({
    brainz: barinzReducer,
    fmlast : FmReducer,
    favourite: favReducer,
    release: releaseReducer
})

export default allReducer