import { MUSICBRAINZ__ADD } from "../actions/types";


const INITIAL_STATE = {
    artist: ''
};


const barinzReducer = (state=INITIAL_STATE, action) => {
  console.log(action.type)  
  switch (action.type) {
      case MUSICBRAINZ__ADD:
          // logic to add user 
        return {
          ...state,
          artist: action.payload,
        }  
      default:
        return state;
    }
  };

  export default barinzReducer;