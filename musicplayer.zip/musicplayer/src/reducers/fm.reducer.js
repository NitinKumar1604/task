import { FM__ADD } from "../actions/types";

const INITIAL_STATE = {
    album: ''
};

const FmReducer = (state = INITIAL_STATE, action) => {
    // console.log(action.type)
    switch (action.type) {
        case FM__ADD:
           return {
             ...state, album: action.payload, 
           };
         default: return state;
    }

};

export default FmReducer;