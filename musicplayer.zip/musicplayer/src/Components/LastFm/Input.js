import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { FM__ADD } from '../../actions/types';
import '../Search/serachform.css'

const Input = ({title}) => {

    const [search, setSearch] = useState(null);

    const searchData = (e) => {
        setSearch(e.target.value)
    }

    const dispatch = useDispatch()
    
    const fmSearch = async () => {
        const url = `http://ws.audioscrobbler.com//2.0/?method=album.search&album=${search}&api_key=2aa4d61b9f0bb9e66fa32d3d507cd19b&format=json`;
        const resdata = await fetch(url)
        const data = await resdata.json();
        dispatch({ type: FM__ADD, payload: data})
    }

    return (
        <div className="container my-4">
            <h1 >Search {title}</h1>
            <div className="searchform">
                <input className="form-control form-control-lg" type="text" placeholder="Search" name="search" onChange={searchData} />
                <button type="button" className="btn btn-primary searchBtn p-2" onClick={fmSearch} >
                    <i className="fa fa-search" aria-hidden="true"></i>
                </button>
            </div>
        </div>
    )
}

export default Input
