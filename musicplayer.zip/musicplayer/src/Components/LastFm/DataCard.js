import React from 'react'

const DataCard = ({artist}) => {
    return (
        <>  
            <tr>
                <th scope="row"></th>
                <td>{artist}</td>
                <td className="text-right"><i class="fa fa-plus-circle fa-2x text-success" aria-hidden="true"></i></td>
            </tr>
        </>
    )
}

export default DataCard
