import React, { useEffect } from 'react'
import { connect, useDispatch } from 'react-redux'

const LastFmSearch = ({data}) => {
    // console.log(data.albummatches.album)
    // console.log(data.albummatches.album)
    const dispatch = useDispatch()
    const favourite = () => {
        
    }

    useEffect(() => {

    }, [])

    return (
        <>
        <table className="table table-striped my-3 lastfm__table">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col">Mark Favourite</th>
                    </tr>
                </thead>
                <tbody>
                        {
                            data ? (
                                data.map((person) => (
                                    <tr>
                                    <th scope="row"></th>
                                    <td>{person.artist}</td>
                                    <td className="text-right"><i className="fa fa-plus-circle fa-2x text-success" aria-hidden="true" onClick={favourite}></i></td>
                                </tr>
                                ))
                            ) : null
                        }
                </tbody>
            </table>
        </>
    )
}

// data is fetched from store but not able to use map function over it
const mapStateToProps = (state) => ({ data : state.fmlast.album.results.albummatches.album })

export default connect(mapStateToProps)(LastFmSearch)
