import React from 'react'
// import SearchInput from '../Search/SearchInput'
import Input from './Input'
import LastFmSearch from './LastFmSearch'




const LastFm = () => {
    return (
        <>
            <section className="container my-4">
                <Input title="LastFm" />
                {/* search result with image */}
                <p><strong>Results:</strong></p><hr/>
                <LastFmSearch />
            </section>
        </>
    )
}

export default LastFm
