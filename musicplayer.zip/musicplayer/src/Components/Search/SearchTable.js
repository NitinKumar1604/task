import React from 'react'
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import './ReleaseTable';

const SearchTable = ({artist}) => {
    // console.log(artist)
    return (
        <>
            <table className="table table-hover w-md-75">
                <thead className="dropdown">
                    <tr>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody className="dropdown">
                    {
                        artist ? (
                            artist.map((person) => (
                                <tr>
                                    <td >{person.title}</td>
                                    <td><Link to="/release">show release</Link></td>    
                                </tr>
                            ))
                        ) : null
                    }
                </tbody>
            </table>
        </>
    )
}

const mapStatetoProps = (state) => ({ artist: state.brainz.artist.cdstubs })

export default connect(mapStatetoProps)(SearchTable)
