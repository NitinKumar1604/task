import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux';
import { MUSICBRAINZ__ADD } from '../../actions/types';
import './serachform.css'

const SearchInput = ({title}) => {

    const [search, setSearch] = useState(null);

    const searchData = (e) => {
        setSearch(e.target.value)
    }

    const dispatch = useDispatch()
    
    const fmSearch = async () => {
        const url = `http://musicbrainz.org/ws/2/cdstub/?query=${search}&fmt=json`;
        const resdata = await fetch(url)
        const data = await resdata.json();
        dispatch({ type: MUSICBRAINZ__ADD, payload: data}) 
        setSearch(null)
    }
    
    useEffect(() => {
        
    }, [])

    return (
        <div className="container my-4">
            <h1 >Search {title}</h1>
            <div className="searchform">
                <input className="form-control form-control-lg" type="text" placeholder="Search" name="search" onChange={searchData} />
                <button type="button" className="btn btn-primary searchBtn p-2" onClick={fmSearch} >
                    <i className="fa fa-search" aria-hidden="true"></i>
                </button>
            </div>
        </div>
    )
}

export default SearchInput
