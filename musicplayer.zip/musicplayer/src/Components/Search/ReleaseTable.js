import React, { useEffect } from 'react'
import { connect, useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'
import { ADD__RELEASE } from '../../actions/types'

const ReleaseTable = ({artist, release }) => {

    const dispatch = useDispatch()

    const name = artist ? artist[0].title : 'eminem'
    console.log(release)

    useEffect(() => {
        const releaseData = async () => {
            const url = `https://musicbrainz.org/ws/2/release/?query=${name}&fmt=json`;
            const resdata = await fetch(url)
            const data = await resdata.json();
            dispatch({ type: ADD__RELEASE, payload: data}) 
        }
        releaseData();
    }, [name])
    

    return (
        <section className="search__res container my-3">
            <table class="table table-hover w-md-75">
                <thead className="dropdown">
                    <tr>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col">{artist[0]?.title}</th>
                    </tr>
                </thead>
                <tbody className="dropdown">
                    <tr>
                        <td></td>
                        <td><Link to="/release">show release</Link></td>
                    </tr>
            
                </tbody>
            </table>
            <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                            <th scope="col">Year</th>
                            <th scope="col">Title</th>  
                            <th scope="col">Release Label</th>
                            <th scope="col">Number of Tracks</th>
                        </tr>
                    </thead>
                    <tbody>
                        {release ? (
                            release.map((person) => (
                                <tr>
                                    <th scope="row"><i class="fa fa-star" aria-hidden="true"></i></th>
                                    <td>{person.date}</td>
                                    <td>{person.title}</td>
                                    <td>11</td>
                                    <td>{person['track-count']}</td>
                                </tr>
                            ))
                        ) : null}
                        
                    </tbody>
            </table>
        </section>
    )
}

const mapStatetoProps = (state) => ({ artist: state.brainz.artist.cdstubs, release: state.release.release.releases })

export default connect(mapStatetoProps)(ReleaseTable)
