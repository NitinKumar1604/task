import React from 'react'
import { connect } from 'react-redux';

const FavTable = ({fav}) => {
    console.log(fav);
    return (
        <>
            <table className="table my-4 table-hover">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col">Last</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row"><i class="fa fa-star" aria-hidden="true"></i></th>
                        <td>The Jackson Five</td>
                        <td><a href="#showRelease">show release</a></td>
                    </tr>
                </tbody>
            </table>
        </>
    )
}
const mapStateToProps = (state) => {
    return {
      fav: state.favourite
    };
  };

export default connect(mapStateToProps)(FavTable)
