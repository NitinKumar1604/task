import React from 'react'
import FavTable from './FavTable'

const Favourites = () => {
    return (
        <section className="container my-4">
            <h1 className="mb-3">Favourites</h1>
            <FavTable />
        </section>
    )
}

export default Favourites
