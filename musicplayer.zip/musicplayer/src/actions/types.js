export const ADD__FAV = 'ADD__FAV';
export const FM__ADD = "FM__ADD";
export const MUSICBRAINZ__ADD = "MUSICBRAINZ__ADD";
export const ADD__RELEASE = "ADD__RELEASE";