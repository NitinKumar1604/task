import React from 'react';
// import './App.css';
import Navbar from './Components/Navbar/Navbar';
import SearchInput from './Components/Search/SearchInput';
import { Switch, Route, Redirect } from 'react-router-dom'
import Favourites from './Components/Favourite/Favourites';
import Results from './Components/Search/SearchResult/Results';
import LastFm from './Components/LastFm/LastFm'
import ReleaseTable from './Components/Search/ReleaseTable';


const App = () => {
  return (
    <>
      <Navbar />
      <Switch>
        <Route exact path='/'>
          <SearchInput title="MusicBrainz"/>
          <Results />
        </Route>
        <Route exact path='/lastfm' component={LastFm} />
        <Route exact path='/favourites' component={Favourites} />
        <Route exact path='/release' component={ReleaseTable} />
        <Redirect to="/" />
      </Switch>
    </>
  );
}

export default App;
